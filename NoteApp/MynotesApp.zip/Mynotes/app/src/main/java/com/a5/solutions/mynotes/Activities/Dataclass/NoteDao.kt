package com.a5.solutions.mynotes.Activities.Dataclass

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface NoteDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(note: Notes)

    @Query("SELECT * FROM notes ORDER BY id ASC")
    fun getall(): LiveData<List<Notes>>
    @Query("SELECT * FROM notes ORDER BY lastUpdated DESC")
    fun getNotesSortedByLastUpdated(): LiveData<List<Notes>>

    @Query("SELECT * FROM notes ORDER BY title ASC")
    fun getNotesSortedByTitle(): LiveData<List<Notes>>

    @Query("SELECT * FROM notes ORDER BY createdDate DESC")
    fun getNotesSortedByCreationDate(): LiveData<List<Notes>>

    @Update
    suspend fun update(note: Notes)

    @Delete
    suspend fun delete(note: Notes)
}