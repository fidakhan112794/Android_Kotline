package com.a5.solutions.mynotes.Activities.Actvities


import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.View.VISIBLE
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.a5.solutions.mynotes.Activities.Adopter.myadopter
import com.a5.solutions.mynotes.Activities.Dataclass.Notes
import com.a5.solutions.mynotes.Activities.Viewmodels.NotesViewModel
import com.a5.solutions.mynotes.R
import com.a5.solutions.mynotes.R.color
import com.a5.solutions.mynotes.databinding.ActivityMainBinding
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.shape.ShapeAppearanceModel

//import java.util.Locale

@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity() {
    lateinit var popserch: PopupMenu
    lateinit var viewModel: NotesViewModel
    lateinit var gridpop: PopupMenu

    //  lateinit var insertFragment: insertFragment
    lateinit var myadopter: myadopter
    lateinit var buttomSheetDialog: BottomSheetDialog
    private lateinit var binding: ActivityMainBinding
    var selectedItemId: Int? = null
    var selectedItemId2: Int? = null
    private var isLinearLayoutManager = true

    @SuppressLint("MissingInflatedId", "ClickableViewAccessibility", "Range", "RestrictedApi")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        window.statusBarColor = Color.parseColor("#252525")

        setContentView(binding.root)

        binding.floatbtn.shapeAppearanceModel = ShapeAppearanceModel().withCornerSize(500f)


        //insertFragment = insertFragment()
        viewModel =
            ViewModelProvider(this, defaultViewModelProviderFactory).get(NotesViewModel::class.java)
        myadopter = myadopter()
        binding.re.adapter = myadopter
        setRecyclerViewLayoutManager()

        viewModel.tlist.observe(this, Observer { notes ->
            notes?.let {
                var v = notes.size
                if (v != 0) {
                    binding.mtxt.visibility = View.GONE
                    binding.mimage.visibility = View.GONE
                } else {
                    binding.mtxt.visibility = View.VISIBLE
                    binding.mimage.visibility = View.VISIBLE
                }
                myadopter.updateNotes(notes)
            }
        })

        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN)

        buttomSheetDialog = BottomSheetDialog(this)

        binding.tb.srchbtn.setOnClickListener {
            visibilty()
        }

        binding.tb.grid.setOnClickListener {
            gridpop = PopupMenu(this, binding.tb.grid)
            gridpop()
        }

        binding.tb.datech.setOnClickListener {
            popserch = PopupMenu(this, it)
            serchpop()
        }

        binding.floatbtn.setOnClickListener {

            val view = layoutInflater.inflate(R.layout.customdiolague, null)
            val title = view.findViewById<EditText>(R.id.cbtitle)
            val content = view.findViewById<EditText>(R.id.cbetxt)
            val inertbtn = view.findViewById<Button>(R.id.inertBtn)
            //  buttomSheetDialog.behavior.shouldExpandOnUpwardDrag(4000L, 400.0F)
            inertbtn.setOnClickListener {
                val txt: String = title.text.toString()
                val content: String = content.text.toString()

                if (txt.isNotEmpty() && content.isNotEmpty()) {

//                    val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
//                    val converter = Converters()
                    val currentDate = java.util.Date()

                    val notes = Notes(null, txt, content, null, currentDate)
                    viewModel.insert(notes)
                    buttomSheetDialog.dismiss()
                } else {
                    Toast.makeText(this, "Please Enter Values", Toast.LENGTH_SHORT).show()
                }
            }

            buttomSheetDialog.setContentView(view)
            buttomSheetDialog.show()
        }

        setupSwipeToDelete()
        setupSearch()
    }

    private fun visibilty() {
        binding.tb.srchbtn.visibility = View.GONE
        binding.tb.datech.visibility = View.GONE
        binding.tb.grid.visibility = View.GONE
        binding.tb.srhtxt.visibility = VISIBLE
        binding.tb.name.visibility = View.GONE
        binding.tb.srhtxt.requestFocus()
    }

    private fun visibilty2() {
        binding.tb.srchbtn.visibility = VISIBLE
        binding.tb.datech.visibility = VISIBLE
        binding.tb.grid.visibility = VISIBLE
        binding.tb.srhtxt.visibility = View.GONE

        binding.tb.name.visibility = VISIBLE
    }

    private fun gridpop() {
        gridpop.menuInflater.inflate(R.menu.grid, gridpop.menu)

        selectedItemId?.let {
            gridpop.menu.findItem(it).isChecked = true
        }

        gridpop.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.gr -> {
                    selectedItemId = item.itemId
                    isLinearLayoutManager = false
                    setRecyclerViewLayoutManager()
                    true
                }

                R.id.li -> {
                    selectedItemId = item.itemId
                    isLinearLayoutManager = true
                    setRecyclerViewLayoutManager()
                    true
                }

                else -> false
            }
        }
        gridpop.show()
    }

    private fun serchpop() {
        popserch.menuInflater.inflate(R.menu.datemodi, popserch.menu)
        selectedItemId2?.let {
            popserch.menu.findItem(it).isChecked = true
        }
        popserch.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.ccdatec -> {
                    selectedItemId2 = item.itemId
                    viewModel.clist.observe(this, Observer { notes ->
                        notes?.let { myadopter.updateNotes(notes) }
                    })

                    true
                }

                R.id.ccdatem -> {
                    selectedItemId2 = item.itemId
                    viewModel.ulist.observe(this, Observer { notes ->
                        notes?.let { myadopter.updateNotes(notes) }
                    })
                    true
                }

                R.id.cctitle -> {
                    selectedItemId2 = item.itemId
                    viewModel.tlist.observe(this, Observer { notes ->
                        notes?.let { myadopter.updateNotes(notes) }
                    })
                    true
                }

                else -> false
            }
        }
        popserch.show()
    }

    private fun setRecyclerViewLayoutManager() {
        binding.re.layoutManager = if (isLinearLayoutManager) {
            LinearLayoutManager(this)
        } else {
            GridLayoutManager(this, 2)
        }
    }

    @Deprecated("This method has been deprecated in favor of using the\n      {@link OnBackPressedDispatcher} via {@link #getOnBackPressedDispatcher()}.\n      The OnBackPressedDispatcher controls how back button events are dispatched\n      to one or more {@link OnBackPressedCallback} objects.")
    override fun onBackPressed() {

        if (binding.tb.srhtxt.visibility == View.VISIBLE) {
            visibilty2()
        } else {
            super.onBackPressed()

        }
    }

    private fun setupSwipeToDelete() {
        val itemTouchHelperCallback = object :
            ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                return false
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.adapterPosition
                val note = myadopter.getNoteAtPosition(position)
                viewModel.delete(note)
                Toast.makeText(this@MainActivity, "Note deleted", Toast.LENGTH_SHORT).show()
            }
        }

        val itemTouchHelper = ItemTouchHelper(itemTouchHelperCallback)
        itemTouchHelper.attachToRecyclerView(binding.re)
    }

    @SuppressLint("ResourceAsColor")
    private fun setupSearch() {
        binding.tb.srhtxt.setBackgroundColor(color.white)

        binding.tb.srhtxt.setOnQueryTextListener(object : SearchView.OnQueryTextListener,
            android.widget.SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                myadopter.filter.filter(query)
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                myadopter.filter.filter(newText)
                return false
            }
        })
    }
}



