package com.a5.solutions.mynotes.Activities.Viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.a5.solutions.mynotes.Activities.Dataclass.NoteDatabase
import com.a5.solutions.mynotes.Activities.Dataclass.NoteRepo
import com.a5.solutions.mynotes.Activities.Dataclass.Notes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class NotesViewModel( application: Application) : AndroidViewModel(application) {
    lateinit var repo: NoteRepo
    lateinit var list: LiveData<List<Notes>>
    lateinit var tlist: LiveData<List<Notes>>
    lateinit var clist: LiveData<List<Notes>>
     lateinit var ulist: LiveData<List<Notes>>


    init {
        val dao = NoteDatabase.getDatabase(application).noteDao()
        repo = NoteRepo(dao)
        var job = viewModelScope.launch {
            list = repo.getall()
        }

        var job2 = viewModelScope.launch {
            tlist = repo.getalpha()
        }
        var job3 = viewModelScope.launch {
            clist = repo.datecreation()
        }
        var job4 = viewModelScope.launch {
            ulist = repo.getupdate()

        }
    }


    fun insert(notes: Notes) = viewModelScope.launch(Dispatchers.IO) {
        repo.inert(notes)
    }

    fun delete(notes: Notes) = viewModelScope.launch(Dispatchers.IO) {
        repo.delete(notes)
    }

    fun update(notes: Notes) = viewModelScope.launch(Dispatchers.IO) {
        repo.update(notes)
    }


}