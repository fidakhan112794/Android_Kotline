package com.a5.solutions.mynotes.Activities.Dataclass

import androidx.lifecycle.LiveData

class NoteRepo(val noteDao: NoteDao) {
     fun getall() :LiveData<List<Notes>>{
      return  noteDao.getall()
    }
    fun getalpha():LiveData<List<Notes>>
    {
        return noteDao.getNotesSortedByTitle()
    }
    fun datecreation():LiveData<List<Notes>>
    {
        return noteDao.getNotesSortedByCreationDate()
    }
    fun getupdate():LiveData<List<Notes>>
    {
        return noteDao.getNotesSortedByLastUpdated()
    }

    suspend fun inert(notes: Notes) {
        noteDao.insert(notes)
    }

    suspend fun delete(notes: Notes) {
        noteDao.delete(notes)
    }

    suspend fun update(notes: Notes) {
        noteDao.update(notes)
    }


}