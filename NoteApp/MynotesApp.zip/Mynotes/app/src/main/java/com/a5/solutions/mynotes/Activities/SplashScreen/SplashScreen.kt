package com.a5.solutions.mynotes.Activities.SplashScreen

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.a5.solutions.mynotes.Activities.Actvities.MainActivity
import com.a5.solutions.mynotes.R

class SplashScreen : AppCompatActivity() {

    private lateinit var progressBar: ProgressBar
    private lateinit var progressTextView: TextView
    private var progressStatus = 0
    private val handler = Handler(Looper.getMainLooper())
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#252525")

        setContentView(R.layout.activity_splash_screen)
        progressBar = findViewById(R.id.progressBar)
        progressTextView = findViewById(R.id.progressTextView)

        simulateLoading()
}
    private fun simulateLoading() {
        Thread {
            while (progressStatus < 100) {
                progressStatus += 1

                handler.post {
                    progressBar.progress = progressStatus
                    progressTextView.text = "$progressStatus%"

                }

                try {
                    Thread.sleep(40) 
                } catch (e: InterruptedException) {
                    e.printStackTrace()
                }
            }

            handler.post {
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()
            }
        }.start()
    }
}

