package com.a5.solutions.mynotes.Activities.Adopter

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.a5.solutions.mynotes.Activities.Dataclass.Notes
import com.a5.solutions.mynotes.Activities.Actvities.updata
import com.a5.solutions.mynotes.R
import com.a5.solutions.mynotes.databinding.VerticalcardBinding
import com.google.android.material.shape.ShapeAppearanceModel
import java.util.Locale

@Suppress("DEPRECATION")
class myadopter() : RecyclerView.Adapter<myadopter.myviewholder>(), Filterable {
    lateinit var co: Context
    private var notes: List<Notes> = listOf()
    private var filteredNotes: List<Notes> = listOf()
    private val colors = arrayListOf(
        R.color.green,
        R.color.pink,
        R.color.yellow,
        R.color.Skyblue
    )

    inner class myviewholder(val binding: VerticalcardBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(note: Notes, position: Int) {
            binding.lrtitle.text = (note.title)
            binding.lrtitle.setTextColor(ContextCompat.getColor(co,R.color.white))
            binding.lrcontext.text = note.description
            val rnds = (0..3).random()

 binding.ok.setBackgroundColor(ContextCompat.getColor(co,colors[rnds]))


        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): myviewholder {
        val binding =
            VerticalcardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        co = parent.context
        return myviewholder(binding)
    }

    override fun getItemCount(): Int {
        return filteredNotes.size
    }

    override fun onBindViewHolder(holder: myviewholder, position: Int) {

       holder.binding.ok.setOnClickListener {
            Toast.makeText(co,"ok click",Toast.LENGTH_SHORT).show()

            val intent = Intent(co, updata::class.java).apply {
//                putExtra("TITLE", notes[position].title)
//                putExtra("DESCRIPTION", notes[position].description)
//                putExtra("CREATED_DATE", notes[position].createdDate)
//                putExtra("id", notes[position].id)
                val notes=Notes(notes[position].id,notes[position].title,notes[position].description,null,notes[position].createdDate)
                putExtra("obj",notes)
            }
            co.startActivity(intent)
        }
        holder.bind(filteredNotes[position], position)


    }

    @SuppressLint("NotifyDataSetChanged")
    fun updateNotes(newNotes: List<Notes>) {
        notes = newNotes
        filteredNotes = newNotes
        notifyDataSetChanged()
    }

    fun getNoteAtPosition(position: Int): Notes {

        return filteredNotes[position]
    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(charSequence: CharSequence?): FilterResults {
                val filterResults = FilterResults()
                if (charSequence.isNullOrEmpty()) {
                    filterResults.values = notes
                } else {
                    val searchQuery = charSequence.toString().toLowerCase(Locale.ROOT)
                    val tempList = notes.filter {
                        it.title.toLowerCase(Locale.ROOT)
                            .contains(searchQuery) || it.description.toLowerCase(Locale.ROOT)
                            .contains(searchQuery)
                    }
                    filterResults.values = tempList
                }
                return filterResults
            }

            @SuppressLint("NotifyDataSetChanged")
            override fun publishResults(
                charSequence: CharSequence?,
                filterResults: FilterResults?
            ) {
                filteredNotes = filterResults?.values as List<Notes>
                notifyDataSetChanged()
            }
        }
    }
}