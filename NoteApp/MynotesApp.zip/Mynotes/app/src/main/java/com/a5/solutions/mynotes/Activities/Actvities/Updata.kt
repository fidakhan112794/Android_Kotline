package com.a5.solutions.mynotes.Activities.Actvities

import android.annotation.SuppressLint
import android.graphics.Color
import android.icu.text.SimpleDateFormat
import android.os.Bundle
import android.text.Editable
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.a5.solutions.mynotes.Activities.Dataclass.Converters
import com.a5.solutions.mynotes.Activities.Dataclass.Notes
import com.a5.solutions.mynotes.Activities.Viewmodels.NotesViewModel
import com.a5.solutions.mynotes.databinding.ActivityUpdataBinding
import java.util.Date
import java.util.Locale
import android.text.TextWatcher as TextTextWatcher

class updata : AppCompatActivity() {
    var createdDate: Long? = null
    var datec: Date? = null
    var id: Int? = null
    var idd: Int? = null
    var iddd: Int? = null
    var changet: String? = null
    var o: String? = null
    private val textHistory = mutableListOf<String>()

    var changec: String? = null
    var white: Int? = null
    private var stack1 = mutableListOf<String>()

    private var stack = mutableListOf<String>()
    lateinit var notes: Notes
    lateinit var viewModel: NotesViewModel
    lateinit var binding: ActivityUpdataBinding

    @SuppressLint("NewApi")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUpdataBinding.inflate(layoutInflater)
        window.statusBarColor = Color.parseColor("#252525")

        binding.utb.srchbtn.visibility = View.GONE
        binding.utb.datech.visibility = View.GONE
        binding.utb.grid.visibility = View.GONE
        viewModel =
            ViewModelProvider(this, defaultViewModelProviderFactory).get(NotesViewModel::class.java)

        setContentView(binding.root)

        val obj = intent.getSerializableExtra("obj", Notes::class.java)
        id = obj?.id
        var title = obj?.title
        val description = obj?.description
        datec = obj!!.createdDate
        binding.changetitle.setText(title)
        binding.changecontent.setText(description)
        var popj = binding.changecontent.text.toString()
        var p = popj.split(" ").filter { it.isNotEmpty() } as MutableList<String>
        idd = p.size


        binding.changecontent.addTextChangedListener(object : TextTextWatcher {

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

                var okk = s.toString()
                stack1 = okk.split(" ").filter { it.isNotEmpty() } as MutableList<String>

                //  idd = stack.size
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }


            override fun afterTextChanged(s: Editable?) {


                var okk = s.toString()
                stack = okk.split(" ").filter { it.isNotEmpty() } as MutableList<String>
                iddd=stack.size


            }
        })
        binding.undo.setOnClickListener {
            // binding.changetitle.setText(idd.toString()+"jhhjhgjgjhgj")

            if (stack.size > idd!!) {

                // Remove the last text state from the list and set it to the EditText
                stack.removeAt(stack.lastIndex)
                var ol: String = " "
                for (x in stack) {
                    ol = ol + " " + x
                }
                binding.changetitle.setText(ol)
                binding.changecontent.setText(ol)         // sMove the cursor to the end of the text

            }
        }
         binding.redo.setOnClickListener {
            var p=idd
            var pp=idd
            var ol: String = " "
            while (pp!!>0) {

            }
            if (p!! < iddd!!){


            }

        }


    }

    override fun onBackPressed() {
        super.onBackPressed()
        var updatad: Date? = java.util.Date()
        if (id != null && datec != null && updatad != null) {
            val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
            val converter = Converters()
            val currentDate = java.util.Date()

            changet = binding.changetitle.text.toString()

            changec = binding.changecontent.text.toString()
            var notes = Notes(id, changet!!, changec!!, updatad, datec!!)
            viewModel.update(notes)
        } else {
            Toast.makeText(this, id.toString(), Toast.LENGTH_SHORT).show()
            Toast.makeText(this, datec.toString(), Toast.LENGTH_SHORT).show()
            Toast.makeText(this, updatad.toString(), Toast.LENGTH_SHORT).show()


        }

    }


}